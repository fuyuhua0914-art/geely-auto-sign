# No shrinking for v1.
