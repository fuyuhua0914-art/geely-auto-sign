package com.geely.autosign;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status;
    private Switch enabled;
    private Button timeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (AlarmScheduler.ACTION_AUTO.equals(getIntent().getAction())) {
            runAuto();
            return;
        }

        setContentView(R.layout.activity_main);
        status = findViewById(R.id.tvStatus);
        enabled = findViewById(R.id.swEnabled);
        timeButton = findViewById(R.id.btnTime);
        Button accessibility = findViewById(R.id.btnAccessibility);
        Button exactAlarm = findViewById(R.id.btnExactAlarm);
        Button battery = findViewById(R.id.btnBattery);
        Button test = findViewById(R.id.btnTest);

        enabled.setChecked(Prefs.enabled(this));
        updateTimeText();
        refreshStatus();

        enabled.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Prefs.setEnabled(this, isChecked);
            if (isChecked) AlarmScheduler.scheduleNext(this); else AlarmScheduler.cancel(this);
            refreshStatus();
        });

        timeButton.setOnClickListener(v -> {
            int h = Prefs.hour(this);
            int m = Prefs.minute(this);
            new TimePickerDialog(this, (view, hourOfDay, minute) -> {
                Prefs.setTime(this, hourOfDay, minute);
                AlarmScheduler.scheduleNext(this);
                updateTimeText();
                refreshStatus();
            }, h, m, true).show();
        });

        accessibility.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Exception e) {
                Toast.makeText(this, "无法打开无障碍设置，请手动进入系统设置", Toast.LENGTH_LONG).show();
            }
        });

        exactAlarm.setOnClickListener(v -> requestExactAlarmAccess());
        battery.setOnClickListener(v -> openBatterySettings());
        test.setOnClickListener(v -> launchGeely());

        AlarmScheduler.scheduleNext(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (status != null) refreshStatus();
    }

    private void runAuto() {
        AlarmScheduler.scheduleNext(this);
        if (!Prefs.enabled(this) || Prefs.signedToday(this)) {
            finish();
            return;
        }
        Prefs.setLastResult(this, "已按计划启动吉利汽车，等待签到结果");
        launchGeely();
        finish();
    }

    private void launchGeely() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.geely.consumer");
        if (launch == null) {
            Prefs.setLastResult(this, "未找到吉利汽车 App（com.geely.consumer）");
            Toast.makeText(this, "未找到吉利汽车 App", Toast.LENGTH_LONG).show();
            refreshStatus();
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(launch);
    }

    private void requestExactAlarmAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                try {
                    Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                    return;
                } catch (Exception ignored) {}
            }
        }
        Toast.makeText(this, "当前已具备准时调度条件", Toast.LENGTH_SHORT).show();
    }

    private void openBatterySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void updateTimeText() {
        timeButton.setText(String.format(Locale.CHINA, "设置签到时间：%02d:%02d", Prefs.hour(this), Prefs.minute(this)));
    }

    private void refreshStatus() {
        if (status == null) return;
        String signed = Prefs.signedToday(this) ? "今天：已签到" : "今天：尚未确认签到";
        String state = Prefs.enabled(this) ? "自动签到：开启" : "自动签到：关闭";
        status.setText(state + "\n" + signed + "\n上次状态：" + Prefs.lastResult(this));
    }
}
