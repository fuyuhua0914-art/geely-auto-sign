package com.geely.autosign;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class Prefs {
    private static final String NAME = "geely_auto_sign";

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) {
        return sp(c).getBoolean("enabled", true);
    }

    static void setEnabled(Context c, boolean enabled) {
        sp(c).edit().putBoolean("enabled", enabled).apply();
    }

    static int hour(Context c) {
        return sp(c).getInt("hour", 9);
    }

    static int minute(Context c) {
        return sp(c).getInt("minute", 0);
    }

    static void setTime(Context c, int h, int m) {
        sp(c).edit().putInt("hour", h).putInt("minute", m).apply();
    }

    static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    static boolean signedToday(Context c) {
        return today().equals(sp(c).getString("last_success", ""));
    }

    static void markSignedToday(Context c) {
        sp(c).edit().putString("last_success", today()).apply();
    }

    static String lastResult(Context c) {
        return sp(c).getString("last_result", "尚未执行");
    }

    static void setLastResult(Context c, String s) {
        sp(c).edit().putString("last_result", s).apply();
    }

    private Prefs() {}
}
