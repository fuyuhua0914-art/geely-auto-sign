package com.geely.autosign;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;
import java.util.Deque;

public class GeelyAccessibilityService extends AccessibilityService {
    private static final String GEELY_PACKAGE = "com.geely.consumer";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long sessionStarted = 0L;
    private int fallbackStage = 0;
    private boolean busy = false;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Prefs.setLastResult(this, "无障碍服务已开启");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!Prefs.enabled(this) || Prefs.signedToday(this) || event == null) return;
        CharSequence pkg = event.getPackageName();
        if (pkg == null || !GEELY_PACKAGE.contentEquals(pkg)) return;

        if (System.currentTimeMillis() - sessionStarted > 30_000L) {
            sessionStarted = System.currentTimeMillis();
            fallbackStage = 0;
        }
        scheduleProcess(350);
    }

    @Override
    public void onInterrupt() {
        Prefs.setLastResult(this, "无障碍服务被系统中断");
    }

    private void scheduleProcess(long delayMs) {
        if (busy) return;
        busy = true;
        handler.postDelayed(() -> {
            try {
                processScreen();
            } finally {
                busy = false;
            }
        }, delayMs);
    }

    private void processScreen() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            scheduleRetry();
            return;
        }

        if (containsExact(root, "签到成功") || containsExact(root, "已签到")) {
            Prefs.markSignedToday(this);
            Prefs.setLastResult(this, "签到成功：" + Prefs.today());
            return;
        }

        // 验证码、滑块等情况不自动处理。
        if (containsAny(root, "验证码", "滑块", "安全验证", "人机验证")) {
            Prefs.setLastResult(this, "检测到验证码/安全验证，已停止自动点击，请人工完成");
            return;
        }

        if (clickExact(root, "签到")) {
            Prefs.setLastResult(this, "已点击“签到”，等待结果");
            fallbackStage = 2;
            handler.postDelayed(this::processScreen, 1600);
            return;
        }

        if (clickExact(root, "我的")) {
            Prefs.setLastResult(this, "已进入“我的”，准备点击签到");
            fallbackStage = 1;
            handler.postDelayed(this::processScreen, 1300);
            return;
        }

        // 吉利部分页面可能是 WebView/自绘，节点不可点击时按用户当前界面比例兜底。
        if (fallbackStage == 0) {
            fallbackStage = 1;
            tapRelative(0.902f, 0.968f); // 底部“我的”
            Prefs.setLastResult(this, "未识别到文字节点，已使用“我的”位置兜底");
            handler.postDelayed(this::processScreen, 1800);
        } else if (fallbackStage == 1) {
            fallbackStage = 2;
            tapRelative(0.835f, 0.192f); // “我的”页右上签到按钮（按用户截图比例）
            Prefs.setLastResult(this, "未识别到签到节点，已使用签到位置兜底");
            handler.postDelayed(this::processScreen, 2200);
        } else {
            scheduleRetry();
        }
    }

    private void scheduleRetry() {
        if (System.currentTimeMillis() - sessionStarted < 20_000L) {
            handler.postDelayed(this::processScreen, 1200);
        } else {
            Prefs.setLastResult(this, "本次未确认签到成功，可打开助手点“立即测试签到”重试");
        }
    }

    private boolean containsAny(AccessibilityNodeInfo root, String... words) {
        for (String w : words) if (containsExact(root, w) || containsPart(root, w)) return true;
        return false;
    }

    private boolean containsPart(AccessibilityNodeInfo root, String word) {
        Deque<AccessibilityNodeInfo> q = new ArrayDeque<>();
        q.add(root);
        while (!q.isEmpty()) {
            AccessibilityNodeInfo n = q.removeFirst();
            CharSequence text = n.getText();
            CharSequence desc = n.getContentDescription();
            if ((text != null && text.toString().contains(word)) ||
                    (desc != null && desc.toString().contains(word))) return true;
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) q.addLast(c);
            }
        }
        return false;
    }

    private boolean containsExact(AccessibilityNodeInfo root, String word) {
        return findExact(root, word) != null;
    }

    private AccessibilityNodeInfo findExact(AccessibilityNodeInfo root, String word) {
        Deque<AccessibilityNodeInfo> q = new ArrayDeque<>();
        q.add(root);
        while (!q.isEmpty()) {
            AccessibilityNodeInfo n = q.removeFirst();
            CharSequence text = n.getText();
            CharSequence desc = n.getContentDescription();
            if ((text != null && word.contentEquals(text.toString().trim())) ||
                    (desc != null && word.contentEquals(desc.toString().trim()))) return n;
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) q.addLast(c);
            }
        }
        return null;
    }

    private boolean clickExact(AccessibilityNodeInfo root, String word) {
        AccessibilityNodeInfo n = findExact(root, word);
        if (n == null) return false;
        AccessibilityNodeInfo cur = n;
        for (int depth = 0; depth < 6 && cur != null; depth++) {
            if (cur.isClickable() && cur.isEnabled()) {
                return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            cur = cur.getParent();
        }
        return false;
    }

    private void tapRelative(float rx, float ry) {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.N) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = dm.widthPixels * rx;
        float y = dm.heightPixels * ry;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 80);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(gesture, null, null);
    }
}
